using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StudentManagementSystem.Data;
using StudentManagementSystem.Models;

namespace StudentManagementSystem.Controllers;

[Authorize]
public class StudentsController : Controller
{
    private readonly ApplicationDbContext _db;
    public StudentsController(ApplicationDbContext db) => _db = db;

    public async Task<IActionResult> Index(string? searchString)
    {
        ViewData["CurrentFilter"] = searchString;
        var query = _db.Students.AsNoTracking();
        if (!string.IsNullOrWhiteSpace(searchString))
        {
            var term = searchString.Trim();
            query = query.Where(s =>
                s.FullName.Contains(term) ||
                s.EnrollmentNumber.Contains(term) ||
                s.Email.Contains(term) ||
                s.Course.Contains(term));
        }
        return View(await query.OrderBy(s => s.FullName).ToListAsync());
    }

    public IActionResult Create() => View(new Student());

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(Student student)
    {
        if (await _db.Students.AnyAsync(s => s.EnrollmentNumber == student.EnrollmentNumber))
            ModelState.AddModelError(nameof(student.EnrollmentNumber), "This enrollment number already exists.");

        if (!ModelState.IsValid) return View(student);

        student.CreatedAt = DateTime.UtcNow;
        _db.Students.Add(student);
        await _db.SaveChangesAsync();
        TempData["Success"] = "Student added successfully.";
        HttpContext.Session.SetString("LastStudentAction", $"Added {student.FullName}");
        return RedirectToAction(nameof(Index));
    }

    public async Task<IActionResult> Details(int? id)
    {
        if (id is null) return NotFound();
        var student = await _db.Students.AsNoTracking().FirstOrDefaultAsync(s => s.Id == id);
        return student is null ? NotFound() : View(student);
    }

    public async Task<IActionResult> Edit(int? id)
    {
        if (id is null) return NotFound();
        var student = await _db.Students.FindAsync(id);
        return student is null ? NotFound() : View(student);
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(int id, Student student)
    {
        if (id != student.Id) return NotFound();
        if (await _db.Students.AnyAsync(s => s.EnrollmentNumber == student.EnrollmentNumber && s.Id != id))
            ModelState.AddModelError(nameof(student.EnrollmentNumber), "This enrollment number already exists.");

        if (!ModelState.IsValid) return View(student);

        var existing = await _db.Students.FindAsync(id);
        if (existing is null) return NotFound();

        existing.EnrollmentNumber = student.EnrollmentNumber;
        existing.FullName = student.FullName;
        existing.Email = student.Email;
        existing.PhoneNumber = student.PhoneNumber;
        existing.Course = student.Course;
        existing.Semester = student.Semester;
        existing.DateOfBirth = student.DateOfBirth;
        existing.Gender = student.Gender;
        await _db.SaveChangesAsync();
        TempData["Success"] = "Student updated successfully.";
        HttpContext.Session.SetString("LastStudentAction", $"Updated {existing.FullName}");
        return RedirectToAction(nameof(Index));
    }

    public async Task<IActionResult> Delete(int? id)
    {
        if (id is null) return NotFound();
        var student = await _db.Students.AsNoTracking().FirstOrDefaultAsync(s => s.Id == id);
        return student is null ? NotFound() : View(student);
    }

    [HttpPost, ActionName("Delete"), ValidateAntiForgeryToken]
    public async Task<IActionResult> DeleteConfirmed(int id)
    {
        var student = await _db.Students.FindAsync(id);
        if (student is not null)
        {
            _db.Students.Remove(student);
            await _db.SaveChangesAsync();
            TempData["Success"] = "Student deleted successfully.";
        }
        return RedirectToAction(nameof(Index));
    }
}
