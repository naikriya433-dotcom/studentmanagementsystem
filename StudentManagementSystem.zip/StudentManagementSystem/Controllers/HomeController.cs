using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StudentManagementSystem.Data;

namespace StudentManagementSystem.Controllers;

public class HomeController : Controller
{
    private readonly ApplicationDbContext _db;
    public HomeController(ApplicationDbContext db) => _db = db;

    public async Task<IActionResult> Index()
    {
        ViewBag.TotalStudents = await _db.Students.CountAsync();
        ViewBag.TotalCourses = await _db.Students.Select(s => s.Course).Distinct().CountAsync();
        ViewBag.RecentStudents = await _db.Students.OrderByDescending(s => s.CreatedAt).Take(5).ToListAsync();
        ViewBag.AdminName = User.Identity?.Name ?? "Administrator";
        return View();
    }

    public IActionResult Error() => View();
}
