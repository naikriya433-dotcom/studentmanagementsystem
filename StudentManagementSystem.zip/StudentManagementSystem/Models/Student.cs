using System.ComponentModel.DataAnnotations;

namespace StudentManagementSystem.Models;

public class Student
{
    public int Id { get; set; }

    [Required, StringLength(20)]
    [Display(Name = "Enrollment Number")]
    public string EnrollmentNumber { get; set; } = string.Empty;

    [Required, StringLength(80)]
    [Display(Name = "Full Name")]
    public string FullName { get; set; } = string.Empty;

    [Required, EmailAddress, StringLength(120)]
    public string Email { get; set; } = string.Empty;

    [Phone, StringLength(20)]
    [Display(Name = "Phone Number")]
    public string? PhoneNumber { get; set; }

    [Required, StringLength(80)]
    public string Course { get; set; } = string.Empty;

    [Range(1, 8)]
    public int Semester { get; set; }

    [DataType(DataType.Date)]
    [Display(Name = "Date of Birth")]
    public DateTime? DateOfBirth { get; set; }

    [Required, StringLength(20)]
    public string Gender { get; set; } = "Prefer not to say";

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}
