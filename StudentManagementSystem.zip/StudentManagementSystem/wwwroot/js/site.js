// Small enhancement: confirm destructive form submissions.
document.addEventListener("submit", function (event) {
    const form = event.target;
    if (form instanceof HTMLFormElement && form.action.includes("/Students/Delete")) {
        if (!window.confirm("Delete this student record permanently?")) {
            event.preventDefault();
        }
    }
});
